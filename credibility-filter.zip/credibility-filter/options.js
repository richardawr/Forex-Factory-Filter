// options.js

// DOM elements
const minPostsSlider = document.getElementById('minPosts');
const minPostsVal = document.getElementById('minPostsVal');
const minMonthsSlider = document.getElementById('minMonths');
const minMonthsVal = document.getElementById('minMonthsVal');
const likesThresholdSlider = document.getElementById('likesThreshold');
const likesThresholdVal = document.getElementById('likesThresholdVal');
const mirsLowCheck = document.getElementById('mirsLow');
const mirsMediumCheck = document.getElementById('mirsMedium');
const mirsHighCheck = document.getElementById('mirsHigh');
const ignoreMirsCheck = document.getElementById('ignoreMirs');
const blockedUsersTextarea = document.getElementById('blockedUsers');
const saveBtn = document.getElementById('saveBtn');
const statusDiv = document.getElementById('status');

// Settings containers for visual greying
const postsSettingDiv = document.getElementById('postsSetting');
const yearsSettingDiv = document.getElementById('yearsSetting');
const likesSettingDiv = document.getElementById('likesSetting');

const DEFAULT_SETTINGS = {
  minPosts: 50,
  minMonths: 3,
  likesThreshold: 5,
  allowedMirs: ['low', 'medium', 'high'],
  ignoreMirs: true,
  blockedUsers: []
};

// Update slider value displays
function bindSliderDisplay(slider, span) {
  slider.addEventListener('input', () => {
    span.textContent = slider.value;
    updateGreyOut(slider.id, parseInt(slider.value, 10));
  });
}
bindSliderDisplay(minPostsSlider, minPostsVal);
bindSliderDisplay(minMonthsSlider, minMonthsVal);
bindSliderDisplay(likesThresholdSlider, likesThresholdVal);

// Grey out a setting row if value === 0
function updateGreyOut(sliderId, value) {
  let div;
  if (sliderId === 'minPosts') div = postsSettingDiv;
  else if (sliderId === 'minMonths') div = yearsSettingDiv;
  else if (sliderId === 'likesThreshold') div = likesSettingDiv;
  if (!div) return;
  if (value === 0) {
    div.classList.add('disabled');
  } else {
    div.classList.remove('disabled');
  }
}

// Handle ignoreMirs checkbox: disable low/medium/high checkboxes
function updateMirsCheckboxesState() {
  const ignore = ignoreMirsCheck.checked;
  mirsLowCheck.disabled = ignore;
  mirsMediumCheck.disabled = ignore;
  mirsHighCheck.disabled = ignore;
  if (ignore) {
    // When ignore is checked, we don't need to store allowedMirs, but we keep them for UI consistency
    // Optionally uncheck? We'll keep as is but disabled.
  } else {
    // ensure at least one is checked? We'll let user decide; if none, then effectively no MIRS allowed.
  }
}

ignoreMirsCheck.addEventListener('change', updateMirsCheckboxesState);

// Save settings
function saveSettings() {
  const settings = {
    minPosts: parseInt(minPostsSlider.value, 10),
    minMonths: parseInt(minMonthsSlider.value, 10),
    likesThreshold: parseInt(likesThresholdSlider.value, 10),
    ignoreMirs: ignoreMirsCheck.checked,
    allowedMirs: [],
    blockedUsers: blockedUsersTextarea.value.split('\n')
                    .map(u => u.trim())
                    .filter(u => u.length > 0)
  };
  
  if (!settings.ignoreMirs) {
    if (mirsLowCheck.checked) settings.allowedMirs.push('low');
    if (mirsMediumCheck.checked) settings.allowedMirs.push('medium');
    if (mirsHighCheck.checked) settings.allowedMirs.push('high');
  }
  
  chrome.storage.sync.set({ fxFilterSettings: settings }, () => {
    statusDiv.textContent = '✅ Settings saved! Reload the Forex Factory thread to apply.';
    setTimeout(() => { statusDiv.textContent = ''; }, 2000);
  });
}

// Load settings
function loadSettings() {
  chrome.storage.sync.get('fxFilterSettings', (data) => {
    const s = data.fxFilterSettings || DEFAULT_SETTINGS;
    minPostsSlider.value = s.minPosts;
    minPostsVal.textContent = s.minPosts;
    minMonthsSlider.value = s.minMonths;
    minMonthsVal.textContent = s.minMonths;
    likesThresholdSlider.value = s.likesThreshold;
    likesThresholdVal.textContent = s.likesThreshold;
    
    ignoreMirsCheck.checked = s.ignoreMirs || false;
    mirsLowCheck.checked = s.allowedMirs.includes('low');
    mirsMediumCheck.checked = s.allowedMirs.includes('medium');
    mirsHighCheck.checked = s.allowedMirs.includes('high');
    
    blockedUsersTextarea.value = (s.blockedUsers || []).join('\n');
    
    // Apply greying based on values
    updateGreyOut('minPosts', s.minPosts);
    updateGreyOut('minMonths', s.minMonths);
    updateGreyOut('likesThreshold', s.likesThreshold);
    updateMirsCheckboxesState();
  });
}

saveBtn.addEventListener('click', saveSettings);
document.addEventListener('DOMContentLoaded', loadSettings);