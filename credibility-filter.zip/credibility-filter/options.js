// Load all settings from storage
async function loadSettings() {
  const result = await chrome.storage.local.get(['filterSettings']);
  const settings = result.filterSettings || {};
  
  // Original filter settings
  document.getElementById('minPosts').value = settings.minPosts ?? 50;
  document.getElementById('minPostsVal').textContent = settings.minPosts ?? 50;
  document.getElementById('minMonths').value = settings.minMonths ?? 3;
  document.getElementById('minMonthsVal').textContent = settings.minMonths ?? 3;
  document.getElementById('likesThreshold').value = settings.likesThreshold ?? 5;
  document.getElementById('likesThresholdVal').textContent = settings.likesThreshold ?? 5;
  
  const mirsLevels = settings.mirsLevels ?? { low: true, medium: true, high: true };
  document.getElementById('mirsLow').checked = mirsLevels.low;
  document.getElementById('mirsMedium').checked = mirsLevels.medium;
  document.getElementById('mirsHigh').checked = mirsLevels.high;
  
  const ignoreMirs = settings.ignoreMirs ?? false;
  document.getElementById('ignoreMirs').checked = ignoreMirs;
  toggleMirsCheckboxes(ignoreMirs);
  
  const blockedUsers = settings.blockedUsers ?? [];
  document.getElementById('blockedUsers').value = blockedUsers.join('\n');
  
  // Crowd‑sourced toggle – default to false (unchecked)
  document.getElementById('enableCrowdIgnore').checked = settings.enableCrowdIgnore ?? false;
  
  // Crowd‑sourced config (using minIgnoreCount)
  const crowdConfig = await chrome.runtime.sendMessage({ action: 'getConfig' });
  document.getElementById('topN').value = crowdConfig.topN;
  document.getElementById('minIgnoreCount').value = crowdConfig.minIgnoreCount;
}

// Save all settings (both original and crowd‑sourced)
async function saveSettings() {
  const filterSettings = {
    minPosts: parseInt(document.getElementById('minPosts').value, 10),
    minMonths: parseInt(document.getElementById('minMonths').value, 10),
    likesThreshold: parseInt(document.getElementById('likesThreshold').value, 10),
    mirsLevels: {
      low: document.getElementById('mirsLow').checked,
      medium: document.getElementById('mirsMedium').checked,
      high: document.getElementById('mirsHigh').checked
    },
    ignoreMirs: document.getElementById('ignoreMirs').checked,
    blockedUsers: document.getElementById('blockedUsers').value.split('\n').filter(u => u.trim().length > 0),
    enableCrowdIgnore: document.getElementById('enableCrowdIgnore').checked
  };
  await chrome.storage.local.set({ filterSettings });
  
  // Save crowd‑sourced config to background
  const crowdConfig = {
    topN: parseInt(document.getElementById('topN').value, 10),
    minIgnoreCount: parseInt(document.getElementById('minIgnoreCount').value, 10)
  };
  await chrome.runtime.sendMessage({ action: 'setConfig', config: crowdConfig });
  
  showStatus('All settings saved. Refreshing candidates...', 'green');
  await refreshCandidates(false);
  showStatus('All settings saved and candidates refreshed.', 'green');
}

// Toggle MIRS checkboxes based on "Ignore MIRS" checkbox
function toggleMirsCheckboxes(ignore) {
  const checkboxes = ['mirsLow', 'mirsMedium', 'mirsHigh'];
  checkboxes.forEach(id => {
    const cb = document.getElementById(id);
    cb.disabled = ignore;
    if (ignore) cb.checked = false;
  });
}

// Refresh the candidate list (display and trigger background rebuild)
async function refreshCandidates(showLoading = true) {
  const refreshBtn = document.getElementById('refreshCrowdBtn');
  const refreshStatus = document.getElementById('refreshStatus');
  if (showLoading) {
    refreshBtn.disabled = true;
    refreshStatus.textContent = 'Updating...';
  }
  try {
    const response = await chrome.runtime.sendMessage({ action: 'refreshCandidates' });
    if (!response.success) throw new Error(response.error || 'Unknown error');
    
    if (showLoading) refreshStatus.textContent = 'Updated!';
    setTimeout(() => { if (refreshStatus.textContent === 'Updated!') refreshStatus.textContent = ''; }, 3000);
    
    await loadCandidates();
  } catch (err) {
    refreshStatus.textContent = 'Error: ' + err.message;
    console.error(err);
  } finally {
    if (showLoading) refreshBtn.disabled = false;
  }
}

// Load and display current candidate list from storage
async function loadCandidates() {
  const container = document.getElementById('candidateList');
  container.innerHTML = 'Loading...';
  try {
    const response = await chrome.runtime.sendMessage({ action: 'getCandidates' });
    const candidates = response.candidates || [];
    if (candidates.length === 0) {
      container.innerHTML = '<div>No candidates yet. Click "Refresh Candidate List Now" to build the list.</div>';
    } else {
      container.innerHTML = candidates.map(u => `<div>${escapeHtml(u)}</div>`).join('');
    }
  } catch (err) {
    container.innerHTML = '<div>Error loading candidates.</div>';
    console.error(err);
  }
}

function showStatus(msg, color) {
  const statusDiv = document.getElementById('status');
  statusDiv.textContent = msg;
  statusDiv.style.color = color;
  setTimeout(() => {
    if (statusDiv.textContent === msg) statusDiv.textContent = '';
  }, 4000);
}

function escapeHtml(str) {
  return str.replace(/[&<>]/g, function(m) {
    if (m === '&') return '&amp;';
    if (m === '<') return '&lt;';
    if (m === '>') return '&gt;';
    return m;
  });
}

// Event listeners
document.getElementById('minPosts').addEventListener('input', (e) => {
  document.getElementById('minPostsVal').textContent = e.target.value;
});
document.getElementById('minMonths').addEventListener('input', (e) => {
  document.getElementById('minMonthsVal').textContent = e.target.value;
});
document.getElementById('likesThreshold').addEventListener('input', (e) => {
  document.getElementById('likesThresholdVal').textContent = e.target.value;
});
document.getElementById('ignoreMirs').addEventListener('change', (e) => {
  toggleMirsCheckboxes(e.target.checked);
});
document.getElementById('saveBtn').addEventListener('click', saveSettings);
document.getElementById('refreshCrowdBtn').addEventListener('click', () => refreshCandidates(true));

// Initial load
loadSettings();
loadCandidates();