// content.js

let settings = {
  minPosts: 10,
  minYears: 1,
  likesThreshold: 10,
  allowedMirs: ['low', 'medium', 'high'],
  ignoreMirs: false,
  blockedUsers: []
};

// ---------- Helper functions ----------
function getPostCount(postElement) {
  const link = postElement.querySelector('.threadpost-header__userbit--userinfo a.darklink');
  if (!link) return 0;
  const match = link.innerText.match(/(\d+)\s+Posts?/);
  return match ? parseInt(match[1], 10) : 0;
}

function getMirsLevel(postElement) {
  const icon = postElement.querySelector('.usernamedisplay .mirs__icon');
  if (!icon) return null;
  if (icon.classList.contains('mirs__icon--low')) return 'low';
  if (icon.classList.contains('mirs__icon--medium')) return 'medium';
  if (icon.classList.contains('mirs__icon--high')) return 'high';
  return null;
}

function getJoinDate(postElement) {
  const span = postElement.querySelector('.threadpost-header__userarea-hidden');
  if (!span) return null;
  const text = span.innerText;
  const match = text.match(/Joined\s+(\w+)\s+(\d{4})/);
  if (!match) return null;
  const month = match[1];
  const year = parseInt(match[2], 10);
  const monthIndex = new Date(Date.parse(month + " 1, 2000")).getMonth();
  if (isNaN(monthIndex)) return null;
  return new Date(year, monthIndex, 1);
}

function getYearsSinceJoin(joinDate) {
  if (!joinDate) return 0;
  const today = new Date();
  let years = today.getFullYear() - joinDate.getFullYear();
  const monthDiff = today.getMonth() - joinDate.getMonth();
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < joinDate.getDate())) {
    years--;
  }
  return years;
}

function getLikeCount(postElement) {
  const likeSpan = postElement.querySelector('.like__count--like span');
  if (!likeSpan) return 0;
  const txt = likeSpan.innerText.trim();
  if (txt === '' || txt === ' ') return 0;
  const likes = parseInt(txt, 10);
  return isNaN(likes) ? 0 : likes;
}

function getUsername(postElement) {
  const usernameSpan = postElement.querySelector('.usernamedisplay__username.username');
  if (!usernameSpan) return null;
  return usernameSpan.innerText.trim();
}

// ---------- Main filter ----------
function isPostAllowed(postElement) {
  const username = getUsername(postElement);
  // Blocked user check (case‑insensitive)
  if (username && settings.blockedUsers.some(blocked => blocked.toLowerCase() === username.toLowerCase())) {
    console.log(`[FX Filter] Blocked user: ${username}`);
    return false;
  }
  
  // Like override (only if threshold > 0)
  const likes = getLikeCount(postElement);
  if (settings.likesThreshold > 0 && likes >= settings.likesThreshold) {
    console.log(`[FX Filter] Kept by likes: ${likes} >= ${settings.likesThreshold}`);
    return true;
  }
  
  // Post count filter (if threshold > 0)
  if (settings.minPosts > 0) {
    const postCount = getPostCount(postElement);
    if (postCount < settings.minPosts) return false;
  }
  
  // MIRS filter (if not ignored)
  if (!settings.ignoreMirs) {
    const mirs = getMirsLevel(postElement);
    if (!mirs || !settings.allowedMirs.includes(mirs)) return false;
  }
  
  // Age filter (if threshold > 0)
  if (settings.minYears > 0) {
    const joinDate = getJoinDate(postElement);
    const yearsJoined = getYearsSinceJoin(joinDate);
    if (yearsJoined < settings.minYears) return false;
  }
  
  return true;
}

function filterPosts() {
  const posts = document.querySelectorAll('div.postbit-wrapper');
  let visible = 0, hidden = 0;
  posts.forEach(post => {
    if (isPostAllowed(post)) {
      post.style.display = '';
      visible++;
    } else {
      post.style.display = 'none';
      hidden++;
    }
  });
  console.log(`[FX Filter] Visible: ${visible}, Hidden: ${hidden} | Settings: minPosts=${settings.minPosts}, minYears=${settings.minYears}, likesThreshold=${settings.likesThreshold}, ignoreMirs=${settings.ignoreMirs}, allowedMirs=${settings.allowedMirs.join(',')}, blockedUsers=${settings.blockedUsers.length}`);
}

// ---------- MutationObserver ----------
let observer = null;
function initMutationObserver() {
  if (observer) observer.disconnect();
  observer = new MutationObserver(() => filterPosts());
  const target = document.getElementById('posts') || document.querySelector('.showthread');
  if (target) observer.observe(target, { childList: true, subtree: true });
}

// ---------- Load settings and start ----------
function loadSettingsAndRun() {
  chrome.storage.sync.get('fxFilterSettings', (data) => {
    if (data.fxFilterSettings) {
      settings = data.fxFilterSettings;
      // ensure arrays exist
      if (!settings.allowedMirs) settings.allowedMirs = [];
      if (!settings.blockedUsers) settings.blockedUsers = [];
    }
    console.log('[FX Filter] Settings loaded:', settings);
    filterPosts();
    initMutationObserver();
  });
}

// Listen for real-time changes
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'sync' && changes.fxFilterSettings) {
    settings = changes.fxFilterSettings.newValue;
    if (!settings.allowedMirs) settings.allowedMirs = [];
    if (!settings.blockedUsers) settings.blockedUsers = [];
    console.log('[FX Filter] Settings updated dynamically:', settings);
    filterPosts();
  }
});

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', loadSettingsAndRun);
} else {
  loadSettingsAndRun();
}