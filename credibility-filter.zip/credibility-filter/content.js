// content.js – hides low‑credibility posts and crowd‑ignored users

let settings = {
  minPosts: 50,
  minMonths: 3,
  likesThreshold: 5,
  allowedMirs: ['low', 'medium', 'high'],
  ignoreMirs: true,          // when true, MIRS levels are ignored
  blockedUsers: [],          // user‑defined blocked usernames
  enableCrowdIgnore: true    // toggle for crowd‑sourced ignore
};

let crowdBlockedSet = new Set();   // usernames from credibilityCandidates

// ---------- Helper functions (unchanged from your original) ----------
function getPostCount(postElement) {
  const link = postElement.querySelector('.threadpost-header__userbit--userinfo a.darklink');
  if (!link) return 0;
  const match = link.innerText.match(/([\d,]+)\s+Posts?/);
  return match ? parseInt(match[1].replace(/,/g, ''), 10) : 0;
}

function getMirsLevel(postElement) {
  const icon = postElement.querySelector('.usernamedisplay .mirs__icon');
  if (!icon) return null;
  if (icon.classList.contains('mirs__icon--low')) return 'low';
  if (icon.classList.contains('mirs__icon--medium')) return 'medium';
  if (icon.classList.contains('mirs__icon--high')) return 'high';
  return null;
}

function getJoinDate(postElement) {
  const span = postElement.querySelector('.threadpost-header__userarea-hidden');
  if (!span) return null;
  const text = span.innerText;
  const match = text.match(/Joined\s+(\w+)\s+(\d{4})/);
  if (!match) return null;
  const month = match[1];
  const year = parseInt(match[2], 10);
  const monthIndex = new Date(Date.parse(month + " 1, 2000")).getMonth();
  if (isNaN(monthIndex)) return null;
  return new Date(year, monthIndex, 1);
}

function getMonthsSinceJoin(joinDate) {
  if (!joinDate) return 0;
  const today = new Date();
  return (today.getFullYear() - joinDate.getFullYear()) * 12
    + (today.getMonth() - joinDate.getMonth())
    - (today.getDate() < joinDate.getDate() ? 1 : 0);
}

function getLikeCount(postElement) {
  const likeSpan = postElement.querySelector('.like__count--like span');
  if (!likeSpan) return 0;
  const txt = likeSpan.innerText.trim();
  if (txt === '' || txt === ' ') return 0;
  const likes = parseInt(txt, 10);
  return isNaN(likes) ? 0 : likes;
}

function getUsername(postElement) {
  const usernameSpan = postElement.querySelector('.usernamedisplay__username.username');
  if (!usernameSpan) return null;
  return usernameSpan.innerText.trim();
}

// ---------- Main filter (hide instead of placeholder) ----------
function isPostAllowed(postElement) {
  const username = getUsername(postElement);
  if (!username) return true;

  const lowerUser = username.toLowerCase();

  // 1. User‑defined blocked list
  if (settings.blockedUsers.some(blocked => blocked.toLowerCase() === lowerUser)) {
    console.log(`[CredibilityFilter] Blocked user: ${username}`);
    return false;
  }

  // 2. Crowd‑sourced ignore (if enabled)
  if (settings.enableCrowdIgnore && crowdBlockedSet.has(lowerUser)) {
    console.log(`[CredibilityFilter] Crowd‑ignored user: ${username}`);
    return false;
  }

  // 3. Like override (only if threshold > 0)
  const likes = getLikeCount(postElement);
  if (settings.likesThreshold > 0 && likes >= settings.likesThreshold) {
    console.log(`[CredibilityFilter] Kept by likes: ${likes} >= ${settings.likesThreshold}`);
    return true;
  }

  // 4. Post count filter
  if (settings.minPosts > 0) {
    const postCount = getPostCount(postElement);
    if (postCount < settings.minPosts) return false;
  }

  // 5. MIRS filter (if not ignored)
  if (!settings.ignoreMirs) {
    const mirs = getMirsLevel(postElement);
    if (!mirs || !settings.allowedMirs.includes(mirs)) return false;
  }

  // 6. Account age filter
  if (settings.minMonths > 0) {
    const joinDate = getJoinDate(postElement);
    const monthsJoined = getMonthsSinceJoin(joinDate);
    if (monthsJoined < settings.minMonths) return false;
  }

  return true;
}

function filterPosts() {
  const posts = document.querySelectorAll('div.postbit-wrapper');
  let visible = 0, hidden = 0;
  posts.forEach(post => {
    if (isPostAllowed(post)) {
      post.style.display = '';
      visible++;
    } else {
      post.style.display = 'none';
      hidden++;
    }
  });
  console.log(`[CredibilityFilter] Visible: ${visible}, Hidden: ${hidden} | Settings: minPosts=${settings.minPosts}, minMonths=${settings.minMonths}, likesThreshold=${settings.likesThreshold}, ignoreMirs=${settings.ignoreMirs}, allowedMirs=${settings.allowedMirs.join(',')}, blockedUsers=${settings.blockedUsers.length}, crowdIgnore=${settings.enableCrowdIgnore} (${crowdBlockedSet.size} candidates)`);
}

// ---------- MutationObserver for infinite scroll ----------
let observer = null;
function initMutationObserver() {
  if (observer) observer.disconnect();
  observer = new MutationObserver(() => filterPosts());
  const target = document.getElementById('posts') || document.querySelector('.showthread');
  if (target) observer.observe(target, { childList: true, subtree: true });
}

// ---------- Load settings (sync) and crowd list (local) ----------
async function loadSettingsAndRun() {
  // Load user settings from chrome.storage.sync
  const syncResult = await chrome.storage.sync.get('fxFilterSettings');
  if (syncResult.fxFilterSettings) {
    settings = { ...settings, ...syncResult.fxFilterSettings };
    if (!settings.allowedMirs) settings.allowedMirs = [];
    if (!settings.blockedUsers) settings.blockedUsers = [];
  }

  // Load crowd‑sourced candidates from chrome.storage.local (set by background.js)
  const localResult = await chrome.storage.local.get(['credibilityCandidates']);
  crowdBlockedSet.clear();
  if (settings.enableCrowdIgnore && localResult.credibilityCandidates) {
    localResult.credibilityCandidates.forEach(u => crowdBlockedSet.add(u.toLowerCase()));
  }

  console.log('[CredibilityFilter] Settings loaded:', settings);
  console.log(`[CredibilityFilter] Crowd‑ignored count: ${crowdBlockedSet.size}`);
  filterPosts();
  initMutationObserver();
}

// Listen for real‑time changes (both sync and local)
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'sync' && changes.fxFilterSettings) {
    settings = { ...settings, ...changes.fxFilterSettings.newValue };
    if (!settings.allowedMirs) settings.allowedMirs = [];
    if (!settings.blockedUsers) settings.blockedUsers = [];
    // Reload crowd list because enableCrowdIgnore might have changed
    chrome.storage.local.get(['credibilityCandidates']).then(result => {
      crowdBlockedSet.clear();
      if (settings.enableCrowdIgnore && result.credibilityCandidates) {
        result.credibilityCandidates.forEach(u => crowdBlockedSet.add(u.toLowerCase()));
      }
      filterPosts();
    });
  } else if (area === 'local' && changes.credibilityCandidates) {
    // Update crowd list when background rebuilds it
    if (settings.enableCrowdIgnore && changes.credibilityCandidates.newValue) {
      crowdBlockedSet.clear();
      changes.credibilityCandidates.newValue.forEach(u => crowdBlockedSet.add(u.toLowerCase()));
      filterPosts();
    }
  }
});

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', loadSettingsAndRun);
} else {
  loadSettingsAndRun();
}