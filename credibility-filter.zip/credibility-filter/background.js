// Configuration defaults
let CONFIG = {
  topN: 15,
  minIgnoreCount: 2,        // require at least 2 top members to ignore a user
  refreshHours: 24
};

async function loadConfig() {
  const saved = await chrome.storage.local.get(['credConfig']);
  if (saved.credConfig) CONFIG = { ...CONFIG, ...saved.credConfig };
}

async function fetchTopMembers() {
  const url = `https://www.forexfactory.com/traders?sort=subscribers&order=desc`;
  const resp = await fetch(url, { credentials: 'include' });
  const html = await resp.text();
  const tableStart = html.indexOf('<table class="memberlist__table');
  if (tableStart === -1) return [];
  const tableEnd = html.indexOf('</table>', tableStart);
  const tableHtml = html.substring(tableStart, tableEnd);
  const rowRegex = /<tr class="(?:even|odd) ">([\s\S]*?)<\/tr>/gi;
  const members = [];
  let rowMatch;
  while ((rowMatch = rowRegex.exec(tableHtml)) !== null && members.length < CONFIG.topN) {
    const row = rowMatch[1];
    const userSpanMatch = row.match(/<span class="usernamedisplay__username username">([^<]+)<\/span>/);
    if (userSpanMatch) {
      const username = userSpanMatch[1].trim();
      if (username) members.push({ username });
    }
  }
  console.log(`[CF] Found ${members.length} top members:`, members.map(m => m.username).join(', '));
  return members;
}

async function fetchIgnoredList(username) {
  const url = `https://www.forexfactory.com/${username}`;
  const resp = await fetch(url, { credentials: 'include' });
  const html = await resp.text();
  const ignoreStart = html.indexOf('data-network="ignore"');
  if (ignoreStart === -1) return [];
  let startDiv = html.lastIndexOf('<div', ignoreStart);
  if (startDiv === -1) return [];
  let divCount = 1;
  let pos = startDiv + 4;
  let endDiv = -1;
  while (pos < html.length) {
    const nextOpen = html.indexOf('<div', pos);
    const nextClose = html.indexOf('</div>', pos);
    if (nextClose === -1) break;
    if (nextOpen !== -1 && nextOpen < nextClose) {
      divCount++;
      pos = nextOpen + 4;
    } else {
      divCount--;
      pos = nextClose + 6;
      if (divCount === 0) {
        endDiv = nextClose + 6;
        break;
      }
    }
  }
  if (endDiv === -1) return [];
  const ignoreHtml = html.substring(startDiv, endDiv);
  const userSpanRegex = /<span class="usernamedisplay__username username">([^<]+)<\/span>/g;
  const ignored = [];
  let userMatch;
  while ((userMatch = userSpanRegex.exec(ignoreHtml)) !== null) {
    const ignoredUser = userMatch[1].trim();
    if (ignoredUser && ignoredUser !== username) ignored.push(ignoredUser);
  }
  console.log(`[CF] ${username} ignores ${ignored.length} users`);
  if (ignored.length) console.log(`[CF] Sample: ${ignored.slice(0, 3).join(', ')}`);
  return ignored;
}

async function rebuildCandidates() {
  console.log('[CF] Rebuilding crowd‑sourced ignore list...');
  const topMembers = await fetchTopMembers();
  if (!topMembers.length) return;
  const ignoredCounts = new Map();
  for (const member of topMembers) {
    const ignored = await fetchIgnoredList(member.username);
    for (const ign of ignored) {
      ignoredCounts.set(ign, (ignoredCounts.get(ign) || 0) + 1);
    }
    await new Promise(r => setTimeout(r, 1000));
  }
  const candidates = [];
  for (const [username, count] of ignoredCounts.entries()) {
    if (count >= CONFIG.minIgnoreCount) {
      candidates.push(username);
    }
  }
  await chrome.storage.local.set({ credibilityCandidates: candidates, lastUpdated: Date.now() });
  console.log(`[CF] Updated candidates: ${candidates.length} users`);
  if (candidates.length) console.log(`[CF] Candidates: ${candidates.slice(0, 10).join(', ')}`);
}

async function scheduleRefresh() {
  await chrome.alarms.clear('refreshCandidates');
  chrome.alarms.create('refreshCandidates', { periodInMinutes: CONFIG.refreshHours * 60 });
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'refreshCandidates') rebuildCandidates();
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'refreshCandidates') {
    rebuildCandidates()
      .then(() => sendResponse({ success: true }))
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true;
  }
  if (msg.action === 'getConfig') {
    sendResponse(CONFIG);
    return false;
  }
  if (msg.action === 'setConfig') {
    CONFIG = { ...CONFIG, ...msg.config };
    chrome.storage.local.set({ credConfig: CONFIG });
    scheduleRefresh();
    sendResponse({ success: true });
    return false;
  }
  if (msg.action === 'getCandidates') {
    chrome.storage.local.get(['credibilityCandidates'])
      .then(result => sendResponse({ candidates: result.credibilityCandidates || [] }))
      .catch(err => sendResponse({ candidates: [], error: err.message }));
    return true;
  }
  return false;
});

(async () => {
  await loadConfig();
  await scheduleRefresh();
  await rebuildCandidates();
})();